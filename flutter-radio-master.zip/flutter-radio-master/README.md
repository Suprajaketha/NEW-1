
# Flutter Radio App

Hey, This is an app demonstarting online radio streaming in flutter. Have a look.


# Demo

Catch the demo in this video.<br>
[![Watch the video](https://img.youtube.com/vi/F6TLx_KavT4/hqdefault.jpg)](https://youtu.be/F6TLx_KavT4)

If you like it, show your :blue_heart: by starring the repo. 

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
=======
# flutter-radio
An sample app demonstrating online radio streaming in flutter
>>>>>>> 7457988e79074fa5eebe7832a190941065c6ca8b
